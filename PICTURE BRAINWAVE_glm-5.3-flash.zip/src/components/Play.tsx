import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { ClueBoard } from "./Tile";
import { categoryOf, type Puzzle } from "../data/puzzles";
import { cn } from "../utils/cn";

export type Result = {
  puzzle: Puzzle;
  solved: boolean;
  points: number;
  mistakes: number;
  hints: number;
};

const MAX_MISTAKES = 4;
const BONUS_TIME = 30;
const ROWS = ["QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"];

export function Play({
  puzzle,
  index,
  total,
  score,
  streak,
  onDone,
  onNext,
  onQuit,
}: {
  puzzle: Puzzle;
  index: number;
  total: number;
  score: number;
  streak: number;
  onDone: (r: Result) => void;
  onNext: () => void;
  onQuit: () => void;
}) {
  const cat = categoryOf(puzzle.cat);
  const answer = puzzle.answer;
  const [guessed, setGuessed] = useState<Set<string>>(new Set());
  const [revealed, setRevealed] = useState<Set<number>>(new Set());
  const [wrong, setWrong] = useState<Set<string>>(new Set());
  const [hints, setHints] = useState(0);
  const [time, setTime] = useState(BONUS_TIME);
  const [status, setStatus] = useState<"playing" | "won" | "lost">("playing");
  const [earned, setEarned] = useState(0);
  const [shake, setShake] = useState(0);
  const doneRef = useRef(false);

  const letterIdx = useMemo(
    () =>
      answer
        .split("")
        .map((c, i) => ({ c, i }))
        .filter((x) => /[A-Z]/.test(x.c)),
    [answer],
  );

  const finish = useCallback(
    (won: boolean, w: Set<string>, h: number, t: number) => {
      if (doneRef.current) return;
      doneRef.current = true;
      const points = won
        ? Math.max(
            10,
            Math.round(120 + Math.max(0, t) * 2 + streak * 25 - (w.size * 15 + h * 40)),
          )
        : 0;
      setEarned(points);
      setStatus(won ? "won" : "lost");
      onDone({ puzzle, solved: won, points, mistakes: w.size, hints: h });
    },
    [onDone, puzzle, streak],
  );

  const guess = useCallback(
    (letter: string) => {
      if (status !== "playing" || doneRef.current) return;
      if (guessed.has(letter) || wrong.has(letter)) return;
      if (answer.includes(letter)) {
        const next = new Set(guessed);
        next.add(letter);
        setGuessed(next);
        const win = letterIdx.every(({ c, i }) => next.has(c) || revealed.has(i));
        if (win) finish(true, wrong, hints, time);
      } else {
        const next = new Set(wrong);
        next.add(letter);
        setWrong(next);
        setShake((s) => s + 1);
        if (next.size >= MAX_MISTAKES) finish(false, next, hints, time);
      }
    },
    [status, guessed, wrong, answer, letterIdx, revealed, finish, hints, time],
  );

  const useHint = () => {
    if (status !== "playing" || hints >= 3) return;
    const pool = letterIdx.filter(({ c, i }) => !guessed.has(c) && !revealed.has(i));
    if (!pool.length) return;
    const pick = pool[Math.floor(Math.random() * pool.length)];
    const next = new Set(revealed);
    next.add(pick.i);
    setRevealed(next);
    setHints((h) => h + 1);
    const win = letterIdx.every(({ c, i }) => guessed.has(c) || next.has(i));
    if (win) finish(true, wrong, hints + 1, time);
  };

  const giveUp = () => {
    if (status !== "playing" || doneRef.current) return;
    const all = new Set(revealed);
    letterIdx.forEach(({ i }) => all.add(i));
    setRevealed(all);
    finish(false, wrong, hints, time);
  };

  /* bonus countdown */
  useEffect(() => {
    if (status !== "playing") return;
    const id = window.setInterval(() => setTime((t) => Math.max(0, t - 1)), 1000);
    return () => window.clearInterval(id);
  }, [status]);

  /* physical keyboard */
  const nextRef = useRef(onNext);
  nextRef.current = onNext;
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const k = ev.key.toUpperCase();
      if (/^[A-Z]$/.test(k)) guess(k);
      if (ev.key === "Enter" && status !== "playing") nextRef.current();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [guess, status]);

  const timePct = (time / BONUS_TIME) * 100;
  const words = answer.split(" ");
  const offsetOf = (wi: number) =>
    words.slice(0, wi).reduce((sum, w) => sum + w.length + 1, 0);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-14 pt-5">
      {/* top bar */}
      <div className="flex items-center justify-between gap-2">
        <button
          onClick={onQuit}
          className="flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-sm font-semibold text-white/70 transition hover:bg-white/10"
        >
          ← Menu
        </button>
        <div className={cn("flex items-center gap-2 rounded-full border px-3 py-1.5", cat.soft)}>
          <span>{cat.icon}</span>
          <span className="text-xs font-bold uppercase tracking-wider">{cat.name}</span>
        </div>
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <span className="text-amber-300">{score.toLocaleString()}</span>
          {streak > 0 && <span className="text-white/50">{streak}🔥</span>}
        </div>
      </div>

      {/* progress dots */}
      <div className="mt-3 flex items-center gap-1.5">
        {Array.from({ length: total }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-1.5 flex-1 rounded-full",
              i < index ? "bg-emerald-400/70" : i === index ? "bg-white/80" : "bg-white/15",
            )}
          />
        ))}
      </div>

      {/* mistakes + timer */}
      <div className="mt-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-1">
          {Array.from({ length: MAX_MISTAKES }).map((_, i) => (
            <span
              key={i}
              className={cn(
                "text-xl transition duration-300",
                i < MAX_MISTAKES - wrong.size ? "opacity-100" : "opacity-20 grayscale",
              )}
            >
              🔬
            </span>
          ))}
          <span className="ml-1.5 text-xs text-white/45">guesses left</span>
        </div>
        <div className="flex w-36 items-center gap-2 sm:w-44">
          <span className="text-sm">⏱️</span>
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-black/40">
            <div
              className={cn(
                "h-full rounded-full transition-all duration-1000 ease-linear",
                timePct > 50 ? "bg-emerald-400" : timePct > 20 ? "bg-amber-400" : "bg-rose-400",
              )}
              style={{ width: `${timePct}%` }}
            />
          </div>
          <span className="w-6 text-right text-xs font-bold text-white/60">{time}</span>
        </div>
      </div>

      {/* clue */}
      <div className="mt-5">
        <ClueBoard tiles={puzzle.tiles} />
      </div>

      {/* definition clue */}
      <div className="mt-4 flex items-center justify-center gap-2 rounded-full border border-white/10 bg-black/25 px-4 py-2">
        <span className="text-base">🔍</span>
        <p className="text-center text-sm text-white/75">
          <span className="font-bold uppercase tracking-wider text-white/40">clue&nbsp;·&nbsp;</span>
          {puzzle.hint}
        </p>
      </div>

      {/* answer slots */}
      <div
        key={shake}
        className={cn(
          "mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-2",
          shake > 0 && "anim-shake",
        )}
      >
        {words.map((word, wi) => (
          <div key={wi} className="flex flex-wrap justify-center gap-1.5">
            {word.split("").map((ch, ci) => {
              const gi = offsetOf(wi) + ci;
              const shown = guessed.has(ch) || revealed.has(gi);
              return (
                <div
                  key={ci}
                  style={{ animationDelay: `${ci * 60}ms` }}
                  className={cn(
                    "grid h-12 w-[10vw] max-w-11 min-w-8 place-items-center rounded-xl border-b-4 font-display text-2xl font-black uppercase",
                    shown
                      ? "anim-pop border-amber-300 bg-white/90 text-slate-900"
                      : "border-white/25 bg-white/5",
                    status === "lost" && !shown && "border-rose-400/50 text-rose-200/70",
                  )}
                >
                  {status === "lost" && !shown ? ch : shown ? ch : "•"}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* keyboard */}
      <div className="mt-6 space-y-2">
        {ROWS.map((row, ri) => (
          <div key={ri} className="flex justify-center gap-1 sm:gap-1.5">
            {row.split("").map((l) => {
              const good = guessed.has(l);
              const bad = wrong.has(l);
              return (
                <button
                  key={l}
                  onClick={() => guess(l)}
                  disabled={good || bad || status !== "playing"}
                  className={cn(
                    "h-11 w-[7.6vw] max-w-11 min-w-7 rounded-lg font-display text-sm font-bold uppercase shadow-[0_3px_0_rgba(0,0,0,0.35)] transition active:translate-y-0.5 active:shadow-none sm:h-12 sm:text-base",
                    good && "bg-emerald-400 text-emerald-950 shadow-none",
                    bad && "bg-rose-500/20 text-white/30 line-through shadow-none",
                    !good && !bad && "bg-white/90 text-slate-900 hover:bg-white",
                  )}
                >
                  {l}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* actions while playing */}
      {status === "playing" && (
        <div className="mt-5 flex items-center justify-center gap-3">
          <button
            onClick={useHint}
            disabled={hints >= 3}
            className="flex items-center gap-2 rounded-full border-2 border-amber-300/50 bg-amber-300/10 px-4 py-2 text-sm font-bold text-amber-200 transition hover:bg-amber-300/20 disabled:opacity-30"
          >
            💡 Hint {hints}/3 <span className="text-xs opacity-70">−40 pts</span>
          </button>
          <button
            onClick={giveUp}
            className="flex items-center gap-2 rounded-full border-2 border-white/15 px-4 py-2 text-sm font-bold text-white/50 transition hover:border-white/30 hover:text-white/80"
          >
            🏳️ Skip
          </button>
        </div>
      )}

      {/* reveal panel */}
      {status !== "playing" && (
        <div
          className={cn(
            "anim-pop mt-6 rounded-[1.75rem] border-4 p-5",
            status === "won"
              ? "border-emerald-300/60 bg-emerald-400/10"
              : "border-rose-300/50 bg-rose-400/10",
          )}
        >
          <div className="flex items-center gap-3">
            <span className="text-3xl">{status === "won" ? "🎉" : "🤔"}</span>
            <div className="min-w-0">
              <p className="font-display text-2xl font-black text-white">
                {status === "won" ? "Nailed it!" : "The answer was"}
              </p>
              <p
                className={cn(
                  "font-display text-lg font-bold",
                  status === "won" ? "text-emerald-200" : "text-rose-200",
                )}
              >
                {answer}
              </p>
            </div>
            <span className="ml-auto shrink-0 rounded-full bg-black/30 px-3 py-1 text-sm font-bold text-amber-300">
              {earned > 0 ? `+${earned}` : "+0"} pts
            </span>
          </div>
          <div className="mt-4 rounded-2xl bg-black/25 p-4">
            <p className="text-xs font-bold uppercase tracking-widest text-white/40">Why it works</p>
            <p className="mt-1 text-sm text-white/85">{puzzle.say}</p>
            <p className="mt-3 text-xs font-bold uppercase tracking-widest text-white/40">
              Did you know
            </p>
            <p className="mt-1 text-sm text-white/85">{puzzle.fact}</p>
          </div>
          <button
            onClick={onNext}
            className="mt-4 w-full rounded-2xl bg-gradient-to-r from-amber-300 to-orange-400 py-3 font-display text-lg font-black text-amber-950 shadow-[0_5px_0_rgba(0,0,0,0.25)] transition active:translate-y-1 active:shadow-none"
          >
            {index + 1 >= total ? "See results →" : "Next clue →"}
          </button>
        </div>
      )}

      {status === "won" && <Confetti />}
    </div>
  );
}

function Confetti() {
  const bits = ["🎉", "✨", "⭐", "🎊", "💡", "🧠", "🏆"];
  const items = Array.from({ length: 20 }).map((_, i) => ({
    e: bits[i % bits.length],
    left: (i * 41) % 96,
    delay: (i % 8) * 0.16,
    dur: 1.9 + (i % 5) * 0.35,
  }));
  return (
    <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {items.map((it, i) => (
        <span
          key={i}
          className="confetti absolute -top-12 text-3xl"
          style={{
            left: `${it.left}%`,
            animationDelay: `${it.delay}s`,
            animationDuration: `${it.dur}s`,
          }}
        >
          {it.e}
        </span>
      ))}
    </div>
  );
}
