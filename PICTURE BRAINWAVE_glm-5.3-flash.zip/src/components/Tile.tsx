import { useId } from "react";
import { cn } from "../utils/cn";
import type { Tile } from "../data/puzzles";

const SCHEMES: Record<string, { a: string; b: string; line: string; ink: string }> = {
  gold: { a: "#fff3c4", b: "#d4a017", line: "#8a6100", ink: "#5c3d00" },
  silver: { a: "#f8fafc", b: "#94a3b8", line: "#475569", ink: "#1e293b" },
  rust: { a: "#ffd9c7", b: "#c2410c", line: "#7c2d12", ink: "#431407" },
  copper: { a: "#ffe0c2", b: "#b45309", line: "#713f12", ink: "#451a03" },
  gas: { a: "#d9fbff", b: "#22d3ee", line: "#0e7490", ink: "#083344" },
};

function ElementTile({
  num,
  sym,
  scheme,
  small,
}: {
  num: number;
  sym: string;
  scheme: "gold" | "silver" | "rust" | "copper" | "gas";
  small?: boolean;
}) {
  const uid = useId().replace(/[:]/g, "");
  const s = SCHEMES[scheme];
  return (
    <svg
      viewBox="0 0 120 120"
      className={cn("h-full w-full drop-shadow-[0_6px_10px_rgba(0,0,0,0.35)]", small && "p-1")}
      aria-label={`element ${num} ${sym}`}
    >
      <defs>
        <linearGradient id={`g${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={s.a} />
          <stop offset="45%" stopColor={s.b} />
          <stop offset="100%" stopColor={s.line} />
        </linearGradient>
        <linearGradient id={`s${uid}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.75" />
          <stop offset="55%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect x="4" y="4" width="112" height="112" rx="18" fill={`url(#g${uid})`} />
      <rect
        x="4"
        y="4"
        width="112"
        height="112"
        rx="18"
        fill="none"
        stroke={s.ink}
        strokeWidth="3"
        strokeOpacity="0.55"
      />
      <rect x="10" y="10" width="100" height="60" rx="14" fill={`url(#s${uid})`} />
      <text
        x="18"
        y="32"
        fill={s.ink}
        fontSize="17"
        fontWeight="700"
        fontFamily="ui-sans-serif, system-ui"
        opacity="0.9"
      >
        {num}
      </text>
      <text
        x="18"
        y="48"
        fill={s.ink}
        fontSize="11"
        fontWeight="700"
        letterSpacing="1"
        fontFamily="ui-sans-serif, system-ui"
        opacity="0.8"
      >
        {scheme === "gas" ? "NOBLE" : "METAL"}
      </text>
      <text
        x="60"
        y="82"
        textAnchor="middle"
        fill={s.ink}
        fontSize="44"
        fontWeight="800"
        fontFamily="ui-sans-serif, system-ui"
      >
        {sym}
      </text>
      {scheme === "gold" && (
        <g opacity="0.55">
          <circle cx="104" cy="20" r="9" fill="#fff8dc" />
          <circle cx="16" cy="104" r="6" fill="#fff8dc" />
        </g>
      )}
    </svg>
  );
}

export function TileView({ tile, small }: { tile: Tile; small?: boolean }) {
  if (tile.kind === "element") {
    return (
      <ElementTile num={tile.num} sym={tile.sym} scheme={tile.scheme} small={small} />
    );
  }
  const tilt = tile.kind === "emoji" ? tile.tilt ?? 0 : 0;
  return (
    <span
      style={tilt ? { transform: `rotate(${tilt}deg)` } : undefined}
      className={cn("select-none leading-none", small ? "text-3xl sm:text-4xl" : "text-6xl sm:text-7xl")}
    >
      {tile.kind === "emoji" ? tile.e : tile.t}
    </span>
  );
}

/** The cartoon clue board. */
export function ClueBoard({ tiles }: { tiles: Tile[] }) {
  const n = tiles.length;
  const small = n > 5;
  return (
    <div
      className={cn(
        "flex flex-wrap items-center justify-center gap-3 rounded-[2rem] border-4 border-white/15 bg-white/5 p-5 shadow-inner shadow-black/30 sm:gap-5 sm:p-8",
        n === 1 && "py-10",
      )}
    >
      {tiles.map((tile, i) => (
        <div
          key={i}
          style={{ animationDelay: `${i * 110}ms` }}
          className={cn(
            "anim-pop",
            tile.kind === "element" ? "h-24 w-24 sm:h-32 sm:w-32" : "flex",
            n === 1 && tile.kind === "emoji" && "text-8xl",
          )}
        >
          <TileView tile={tile} small={small} />
        </div>
      ))}
    </div>
  );
}
