import { CATEGORIES, PUZZLES, type CategoryId, type Tile } from "../data/puzzles";
import { TileView } from "./Tile";
import { cn } from "../utils/cn";

const SHOWCASE: { answer: string; caption: string; tiles: Tile[] }[] = [
  {
    answer: "MOSCOW",
    caption: "🕌 mosque + 🐮 cow",
    tiles: [
      { kind: "emoji", e: "🕌" },
      { kind: "emoji", e: "🐮" },
    ],
  },
  {
    answer: "GOLD",
    caption: "element №79 in golden hues",
    tiles: [{ kind: "element", num: 79, sym: "Au", scheme: "gold" }],
  },
  {
    answer: "SEVEN",
    caption: "⭐ ×7 — a prime, too",
    tiles: Array.from({ length: 7 }, () => ({ kind: "emoji", e: "⭐" }) as Tile),
  },
];

export type Progress = Record<CategoryId, number>;

export function Home({
  progress,
  totalScore,
  bestStreak,
  onPlay,
  onReset,
}: {
  progress: Progress;
  totalScore: number;
  bestStreak: number;
  onPlay: (cat: CategoryId | "mixed") => void;
  onReset: () => void;
}) {
  const counts: Record<string, number> = CATEGORIES.reduce((acc, c) => {
    acc[c.id] = progress[c.id] ?? 0;
    return acc;
  }, {} as Record<string, number>);
  const totals: Record<string, number> = CATEGORIES.reduce((acc, c) => {
    acc[c.id] = PUZZLES.filter((p) => p.cat === c.id).length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-16 pt-10 sm:pt-14">
      <header className="text-center">
        <div className="mx-auto mb-4 flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-white/70 backdrop-blur">
          <span className="animate-[wiggle_2s_ease-in-out_infinite]">🧠</span> picture rebus quiz
        </div>
        <h1 className="font-display text-5xl font-black leading-[0.95] tracking-tight text-white drop-shadow-[0_4px_0_rgba(0,0,0,0.25)] sm:text-7xl">
          PICTURE
          <span className="bg-gradient-to-r from-amber-300 via-pink-300 to-violet-300 bg-clip-text text-transparent">
            {" "}
            BRAINWAVE
          </span>
        </h1>
        <p className="mx-auto mt-4 max-w-xl text-balance text-sm text-white/70 sm:text-base">
          Every clue is a cartoon picture that sounds like the answer. 🕌 + 🐮 = Moscow. 🏠 = Ohm.
          Guess the word, collect the facts, become insufferable at dinner parties.
        </p>
      </header>

      <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
        <Stat label="Score" value={totalScore.toLocaleString()} icon="🏆" />
        <Stat label="Best streak" value={`${bestStreak}🔥`} icon="" />
        <Stat
          label="Solved"
          value={`${Object.values(counts).reduce((a, b) => a + b, 0)}/${Object.values(totals).reduce((a, b) => a + b, 0)}`}
          icon="✅"
        />
      </div>

      {/* how it works — the three classic examples */}
      <div className="mt-8 rounded-[1.75rem] border-4 border-white/10 bg-white/5 p-5">
        <p className="text-center text-xs font-bold uppercase tracking-[0.22em] text-white/45">
          how it works
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          {SHOWCASE.map((s) => (
            <div
              key={s.answer}
              className="flex flex-col items-center rounded-2xl border border-white/10 bg-black/20 p-4"
            >
              <div className="flex min-h-16 flex-wrap items-center justify-center gap-1 text-2xl">
                {s.tiles.map((t, i) =>
                  t.kind === "element" ? (
                    <div key={i} className="h-14 w-14 text-base">
                      <TileView tile={t} small />
                    </div>
                  ) : (
                    <div key={i} className="flex text-2xl">
                      <TileView tile={t} small />
                    </div>
                  ),
                )}
              </div>
              <p className="mt-3 font-display text-lg font-black tracking-wide text-white">
                = {s.answer}
              </p>
              <p className="text-center text-[11px] text-white/50">{s.caption}</p>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => onPlay("mixed")}
        className="group mt-8 flex w-full items-center justify-between gap-4 rounded-[1.75rem] border-4 border-white/20 bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-rose-500 p-5 text-left shadow-[0_10px_0_rgba(0,0,0,0.25)] transition active:translate-y-1 active:shadow-[0_6px_0_rgba(0,0,0,0.25)]"
      >
        <div>
          <p className="font-display text-2xl font-black text-white">Mixed Brainwave</p>
          <p className="text-sm text-white/80">10 random clues from every category</p>
        </div>
        <span className="text-4xl transition group-hover:rotate-12">🎲</span>
      </button>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {CATEGORIES.map((c) => {
          const done = counts[c.id];
          const total = totals[c.id];
          const pct = Math.round((done / total) * 100);
          return (
            <button
              key={c.id}
              onClick={() => onPlay(c.id)}
              className="group relative overflow-hidden rounded-[1.75rem] border-4 border-white/15 bg-white/5 p-5 text-left transition hover:-translate-y-1 hover:border-white/40 hover:bg-white/10"
            >
              <div
                className={cn(
                  "absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-to-br opacity-30 blur-xl transition group-hover:opacity-60",
                  c.grad,
                )}
              />
              <div className="relative flex items-start gap-3">
                <span
                  className={cn(
                    "grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br text-3xl shadow-lg",
                    c.grad,
                  )}
                >
                  {c.icon}
                </span>
                <div className="min-w-0">
                  <h2 className="font-display text-xl font-bold text-white">{c.name}</h2>
                  <p className="text-xs text-white/60">{c.blurb}</p>
                </div>
              </div>
              <div className="relative mt-4">
                <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-white/50">
                  <span>
                    {done}/{total} solved
                  </span>
                  <span>{pct}%</span>
                </div>
                <div className="mt-1.5 h-2.5 overflow-hidden rounded-full bg-black/40">
                  <div
                    className={cn("h-full rounded-full bg-gradient-to-r transition-all", c.grad)}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            </button>
          );
        })}
      </div>

      <div className="mt-10 text-center">
        <button
          onClick={onReset}
          className="rounded-full border border-white/15 px-4 py-2 text-xs font-semibold text-white/40 transition hover:border-white/30 hover:text-white/70"
        >
          Reset progress
        </button>
      </div>
    </div>
  );
}

function Stat({ label, value, icon }: { label: string; value: string; icon: string }) {
  return (
    <div className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 backdrop-blur">
      {icon && <span className="text-lg">{icon}</span>}
      <span className="text-xs font-bold uppercase tracking-wider text-white/50">{label}</span>
      <span className="font-display text-base font-bold text-white">{value}</span>
    </div>
  );
}
