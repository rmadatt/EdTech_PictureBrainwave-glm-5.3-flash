import { categoryOf, type CategoryId } from "../data/puzzles";
import type { Result } from "./Play";
import { cn } from "../utils/cn";

export function Summary({
  mode,
  results,
  onReplay,
  onHome,
}: {
  mode: CategoryId | "mixed";
  results: Result[];
  onReplay: () => void;
  onHome: () => void;
}) {
  const solved = results.filter((r) => r.solved);
  const points = results.reduce((s, r) => s + r.points, 0);
  const hints = results.reduce((s, r) => s + r.hints, 0);
  const acc = results.length ? Math.round((solved.length / results.length) * 100) : 0;
  const grade =
    acc === 100 ? "🧠 GENIUS" : acc >= 80 ? "🌟 MASTERMIND" : acc >= 50 ? "🔎 SHARP" : "📚 KEEP GOING";
  const cat = mode === "mixed" ? null : categoryOf(mode);

  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-16 pt-8">
      <div className="rounded-[2rem] border-4 border-white/15 bg-white/5 p-6 text-center">
        <p className="text-xs font-bold uppercase tracking-[0.25em] text-white/45">
          {cat ? `${cat.icon} ${cat.name}` : "🎲 Mixed round"} complete
        </p>
        <h1 className="mt-2 font-display text-4xl font-black text-white sm:text-5xl">{grade}</h1>

        <div className="mt-6 grid grid-cols-3 gap-3">
          <Box label="Score" value={points.toLocaleString()} tone="text-amber-300" />
          <Box label="Solved" value={`${solved.length}/${results.length}`} tone="text-emerald-300" />
          <Box label="Hints used" value={`${hints}`} tone="text-sky-300" />
        </div>

        <div className="mt-4 h-3 overflow-hidden rounded-full bg-black/40">
          <div
            className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-amber-300 to-rose-400 transition-all duration-700"
            style={{ width: `${acc}%` }}
          />
        </div>
        <p className="mt-1.5 text-xs font-semibold text-white/50">{acc}% accuracy</p>
      </div>

      <div className="mt-6 space-y-2">
        {results.map((r, i) => {
          const c = categoryOf(r.puzzle.cat);
          return (
            <div
              key={i}
              className={cn(
                "flex items-center gap-3 rounded-2xl border-2 p-3",
                r.solved
                  ? "border-emerald-300/30 bg-emerald-400/5"
                  : "border-white/10 bg-white/5",
              )}
            >
              <span className="text-2xl">{r.solved ? "✅" : "❌"}</span>
              <div className="min-w-0 flex-1">
                <p className="truncate font-display text-lg font-bold text-white">
                  {r.puzzle.answer}
                </p>
                <p className="truncate text-xs text-white/50">{r.puzzle.say}</p>
              </div>
              <span className={cn("shrink-0 text-xs font-bold uppercase tracking-wider", c.accent)}>
                {c.icon} {c.name.split(" ")[0]}
              </span>
              <span
                className={cn(
                  "shrink-0 text-sm font-bold",
                  r.points > 0 ? "text-amber-300" : "text-white/30",
                )}
              >
                {r.points > 0 ? `+${r.points}` : "—"}
              </span>
            </div>
          );
        })}
      </div>

      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <button
          onClick={onReplay}
          className="flex-1 rounded-2xl bg-gradient-to-r from-amber-300 to-orange-400 py-3.5 font-display text-lg font-black text-amber-950 shadow-[0_5px_0_rgba(0,0,0,0.25)] transition active:translate-y-1 active:shadow-none"
        >
          🔁 Play again
        </button>
        <button
          onClick={onHome}
          className="flex-1 rounded-2xl border-2 border-white/20 bg-white/5 py-3.5 font-display text-lg font-bold text-white transition hover:bg-white/10"
        >
          🏠 All categories
        </button>
      </div>
    </div>
  );
}

function Box({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className="rounded-2xl bg-black/25 p-3">
      <p className={cn("font-display text-2xl font-black", tone)}>{value}</p>
      <p className="text-[10px] font-bold uppercase tracking-widest text-white/40">{label}</p>
    </div>
  );
}
