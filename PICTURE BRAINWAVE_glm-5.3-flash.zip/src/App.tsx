import { useCallback, useEffect, useMemo, useState } from "react";
import { Home, type Progress } from "./components/Home";
import { Play, type Result } from "./components/Play";
import { Summary } from "./components/Summary";
import { PUZZLES, byCategory, type CategoryId, type Puzzle } from "./data/puzzles";

const STORAGE_KEY = "picture-brainwave-v1";
const MIXED_SIZE = 10;

type Saved = {
  solved: Record<string, true>;
  totalScore: number;
  bestStreak: number;
};

const EMPTY: Saved = { solved: {}, totalScore: 0, bestStreak: 0 };

function load(): Saved {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return EMPTY;
    const parsed = JSON.parse(raw) as Partial<Saved>;
    return { ...EMPTY, ...parsed, solved: parsed.solved ?? {} };
  } catch {
    return EMPTY;
  }
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

type Mode = CategoryId | "mixed";

export default function App() {
  const [saved, setSaved] = useState<Saved>(() => load());
  const [screen, setScreen] = useState<"home" | "play" | "summary">("home");
  const [mode, setMode] = useState<Mode>("mixed");
  const [queue, setQueue] = useState<Puzzle[]>([]);
  const [idx, setIdx] = useState(0);
  const [results, setResults] = useState<Result[]>([]);
  const [runScore, setRunScore] = useState(0);
  const [streak, setStreak] = useState(0);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
    } catch {
      /* ignore */
    }
  }, [saved]);

  const startRound = useCallback((m: Mode) => {
    let list: Puzzle[];
    if (m === "mixed") {
      const fresh = PUZZLES.filter((p) => !load().solved[p.id]);
      const pool = fresh.length >= MIXED_SIZE ? fresh : PUZZLES;
      list = shuffle(pool).slice(0, MIXED_SIZE);
    } else {
      const all = byCategory(m);
      const fresh = all.filter((p) => !load().solved[p.id]);
      const pool = fresh.length ? fresh : all;
      list = shuffle(pool);
    }
    setMode(m);
    setQueue(list);
    setIdx(0);
    setResults([]);
    setRunScore(0);
    setStreak(0);
    setScreen("play");
  }, []);

  const handleDone = useCallback((r: Result) => {
    setResults((prev) => [...prev, r]);
    setRunScore((s) => s + r.points);
    setStreak((s) => (r.solved ? s + 1 : 0));
    setSaved((prev) => ({
      solved: r.solved ? { ...prev.solved, [r.puzzle.id]: true } : prev.solved,
      totalScore: prev.totalScore + r.points,
      bestStreak: r.solved ? Math.max(prev.bestStreak, streak + 1) : prev.bestStreak,
    }));
  }, [streak]);

  const handleNext = useCallback(() => {
    if (idx + 1 >= queue.length) setScreen("summary");
    else setIdx((i) => i + 1);
  }, [idx, queue.length]);

  const progress = useMemo(() => {
    const p = {} as Progress;
    for (const cat of ["geography", "math", "physics", "chemistry", "biology"] as CategoryId[]) {
      p[cat] = byCategory(cat).filter((x) => saved.solved[x.id]).length;
    }
    return p;
  }, [saved.solved]);

  const current = queue[idx];

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#0b0a1f] text-white antialiased">
      {/* animated background */}
      <div className="pointer-events-none absolute inset-0 opacity-70">
        <div className="animate-[blob_18s_ease-in-out_infinite] absolute -left-24 -top-24 h-96 w-96 rounded-full bg-violet-600/40 blur-3xl" />
        <div className="animate-[blob_22s_ease-in-out_infinite_reverse] absolute -right-20 top-20 h-96 w-96 rounded-full bg-sky-500/30 blur-3xl" />
        <div className="animate-[blob_26s_ease-in-out_infinite] absolute bottom-0 left-1/3 h-80 w-80 rounded-full bg-rose-500/25 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-10%,rgba(255,255,255,0.12),transparent_60%)]" />
      </div>

      <div className="relative">
        {screen === "home" && (
          <Home
            progress={progress}
            totalScore={saved.totalScore}
            bestStreak={saved.bestStreak}
            onPlay={startRound}
            onReset={() => setSaved(EMPTY)}
          />
        )}

        {screen === "play" && current && (
          <Play
            key={current.id}
            puzzle={current}
            index={idx}
            total={queue.length}
            score={runScore}
            streak={streak}
            onDone={handleDone}
            onNext={handleNext}
            onQuit={() => setScreen("home")}
          />
        )}

        {screen === "summary" && (
          <Summary
            mode={mode}
            results={results}
            onReplay={() => startRound(mode)}
            onHome={() => setScreen("home")}
          />
        )}
      </div>

      <footer className="relative pb-6 text-center text-[11px] text-white/30">
        {PUZZLES.length} picture riddles · type on your keyboard or tap the letters
      </footer>
    </div>
  );
}
